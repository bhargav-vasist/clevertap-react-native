#import "CTInAppDisplayViewController.h"

@interface CTInterstitialViewController : CTInAppDisplayViewController

@end
