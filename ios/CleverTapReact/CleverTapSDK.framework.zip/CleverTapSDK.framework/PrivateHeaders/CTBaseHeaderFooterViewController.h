#import "CTInAppDisplayViewController.h"

@interface CTBaseHeaderFooterViewController : CTInAppDisplayViewController

@end
