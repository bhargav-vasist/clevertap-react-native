#import "CTInAppDisplayViewController.h"

@interface CTCoverImageViewController : CTInAppDisplayViewController

@end

