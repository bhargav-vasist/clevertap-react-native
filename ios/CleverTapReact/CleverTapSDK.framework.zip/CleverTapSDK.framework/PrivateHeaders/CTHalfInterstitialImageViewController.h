#import "CTInAppDisplayViewController.h"

@interface CTHalfInterstitialImageViewController : CTInAppDisplayViewController

@end

